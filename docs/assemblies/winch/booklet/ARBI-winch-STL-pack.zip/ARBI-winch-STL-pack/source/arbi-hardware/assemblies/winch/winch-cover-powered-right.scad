// ARBI winch-cover-powered-right 0.1.0 — concept-unvalidated.
include <../../lib/winch-cover.scad>
wc_print_panel(true,4);
