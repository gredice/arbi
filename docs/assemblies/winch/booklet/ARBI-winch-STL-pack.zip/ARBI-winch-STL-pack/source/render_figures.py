"""Render assembly illustrations from the exported STL files, using VTK >=9.4."""
from pathlib import Path
import json,math
import numpy as np
import vtk

ROOT=Path(__file__).resolve().parents[1]
FIGS=ROOT/'figures'
FIGS.mkdir(exist_ok=True)
WHITE=(.94,.94,.92); CORE=(.12,.14,.15); STEEL=(.66,.70,.73); DARK=CORE
W=246.9
POWERED=False
cache={}
manifest={}
registry=json.loads((ROOT/'source/arbi-hardware/models.json').read_text())
outputs={m['id']:m['output'] for m in registry['models']}

def T(x=0,y=0,z=0):
    m=np.eye(4);m[:3,3]=[x,y,z];return m
def R(axis,angle):
    a=np.deg2rad(angle);c,s=np.cos(a),np.sin(a);m=np.eye(4)
    if axis=='x':m[:3,:3]=[[1,0,0],[0,c,-s],[0,s,c]]
    elif axis=='y':m[:3,:3]=[[c,0,s],[0,1,0],[-s,0,c]]
    else:m[:3,:3]=[[c,-s,0],[s,c,0],[0,0,1]]
    return m
DR=T(z=80)@R('y',90)@R('z',180)

def A(name,m=None):
    # Role color is stable in installed, exploded and inventory views.
    c=WHITE if name in ['coupling-guard','pole-nut-cover','pole-nut-cover-bottom'] or (name.startswith('cover-') and name not in ['cover-clip','cover-cable-anchor']) else CORE
    return {'file':'models/arbi/'+outputs['winch-'+name],'matrix':(np.eye(4) if m is None else m).tolist(),'color':c}
def H(name,m=None,c=STEEL):return {'file':f'models/reference/{name}.stl','matrix':(np.eye(4) if m is None else m).tolist(),'color':c}
def transform(items,m):
    return [{**p,'matrix':(m@np.array(p['matrix'])).tolist()} for p in items]

def drum_parts(explode=0,clamp=True,tail=True,hardware=True,shaft=False):
    count=3 if POWERED else 2
    variant='powered' if POWERED else 'passive'
    parts=[A('drum-flange',T(z=-explode))]
    for i in range(count):parts.append(A(f'drum-{variant}-{i+1}',T(z=6+i*W/count+i*explode)))
    parts.append(A('drum-flange-right',T(z=W+12+count*explode)@R('x',180)))
    for i in range(count+1):parts.append(A('drum-alignment-pin',T(26,0,6+i*W/count-4+i*explode)))
    if clamp:
        for a in [0,180]:parts.append(A('drum-clamp-half',T(z=W+12+2*explode)@R('z',a)))
    if tail:parts.append(A('drum-tail-clamp',T(-14,49,W+12+2*explode)))
    if hardware:
        for angle in [0,115,240]:
            x,y=39*math.cos(math.radians(angle)),39*math.sin(math.radians(angle))
            parts.append(H('tie-rod-M5x610' if POWERED else 'tie-rod-M5x280',T(x,y,-9)))
            for z in [-1,W+12]:parts.append(H('washer-M5',T(x,y,z)))
            parts.append(H('nyloc-M5',T(x,y,-6)))
            parts.append(H('nyloc-M5',T(x,y,W+13)))
    if shaft:parts.append(H('shaft-8x660' if POWERED else 'shaft-8x340',T(z=W+66-(660 if POWERED else 340))))
    return parts

def clamp_hardware():
    out=[]
    for x in [-26,26]:
        for y in [-9,9]:
            out.extend([H('bolt-M4x25',T(x,y,W+5.2)),H('washer-M4',T(x,y,W+5.2)),
              H('washer-M4',T(x,y,W+18)),H('nyloc-M4',T(x,y,W+18.8))])
    for x in [-12,12]:
        out.extend([H('bolt-M4x45',T(x,16.8,W+25)@R('x',90)),
          H('washer-M4',T(x,16.8,W+25)@R('x',90)),
          H('washer-M4',T(x,-16,W+25)@R('x',90)),
          H('nyloc-M4',T(x,-16.8,W+25)@R('x',90))])
    return out

def rings(c=STEEL,explode=0):
    out=[]
    for name,x in [('bearing-608',-9),('bearing-608',W+34),('inner-ring-spacer',-11),
                   ('inner-ring-spacer',W+41),('shaft-collar-8',-21),('shaft-collar-8',W+43)]:
        xx=x-explode if x<0 else x+explode
        out.append(H(name,T(xx,0,80)@R('y',90),c))
    return out

def supports(caps=True,cap_lift=0,motor=True,bolts=False):
    out=[H('base-plate-powered' if POWERED else 'base-plate-passive',c=(.85,.87,.89)),A('bearing-lower',T(-5.5)),
      A('bearing-lower',T(W+37.5)@R('z',180))]
    if caps:
        for x in [-5.5,W+37.5]:out.append(A('bearing-cap',T(x,0,80.2+cap_lift)))
    if motor:out.append(A('motor-stand',T(W+93)))
    if bolts:
        if caps:
            for x in [-5.5,W+37.5]:
                for y in [-18,18]:
                    out.extend([H('bolt-M5x35',T(x,y,97)@R('x',180)),
                        H('washer-M5',T(x,y,96)),H('nut-M5',T(x,y,67.25))])
        for x,ys in [(-21.5,[-40,40]),(W+53.5,[-40,40]),(W+113,[-44,44]),(W+155,[-44,44])]:
            for y in ys:
                out.extend([H('bolt-M6x30',T(x,y,9.6)@R('x',180)),H('washer-M6',T(x,y,8)),
                  H('washer-M6',T(x,y,-9.6)),H('nyloc-M6',T(x,y,-15.6))])
    return out

def coupling(explode=0,c=STEEL):
    m=T(W+56,0,80)@R('y',90)
    return [H('coupling-hub',m@T(z=-explode),c),H('coupling-spider',m@T(z=8.1),CORE),
      H('coupling-hub',m@T(z=25+explode)@R('x',180)@R('z',60),c)]

def motor_hardware():
    out=[]
    face=W+93
    for y in [-23.57,23.57]:
        for z in [-23.57,23.57]:
            # Representative M4 through-screws: head on motor flange, nut on stand.
            out.extend([H('bolt-M4x25',T(face+8.8,y,80+z)@R('y',-90)),
                H('washer-M4',T(face+8,y,80+z)@R('y',90)),
                H('washer-M4',T(face-8,y,80+z)@R('y',-90)),
                H('nyloc-M4',T(face-8.8,y,80+z)@R('y',-90))])
    return out

def cover_hardware():
    out=[]
    face=W+93
    for y in [-38.5,38.5]:
        for z in [-20,20]:
            out.extend([H('bolt-M4x20',T(face-12.8,y,80+z)@R('y',90)),
                H('washer-M4',T(face-12.8,y,80+z)@R('y',90)),
                H('washer-M4',T(face,y,80+z)@R('y',90)),
                H('nyloc-M4',T(face+.8,y,80+z)@R('y',90))])
    return out


def full(guard=False,feet=False):
    out=supports(bolts=True)+motor_hardware()+transform(drum_parts(shaft=True)+clamp_hardware(),DR)+rings()+coupling()
    out.append(H('motor-23HS40-reference',T(W+93,0,80)@R('y',90),DARK))
    if guard:
        out.append(A('coupling-guard',T(W+85,0,80)@R('y',-90)))
        out+=cover_hardware()
    if feet:
        out+=desk_feet()
        for x in [98.45,148.45]:
            for y in [-60,60]:out.extend([H('bolt-M8x35',T(x,y,1.6)@R('x',180)),H('washer-M8',T(x,y,0)),H('washer-M8',T(x,y,-17.6)),H('nyloc-M8',T(x,y,-25.6))])
    return out

def desk_feet(drop=0):
    out=[]
    for y in [-60,60]:
        out.append(A('desk-foot-short',T(98.45,y,-43-drop)@R('z',180)@T(-22,-30)))
        out.append(A('desk-foot-long',T(148.45,y,-43-drop)@T(-22,-30)))
    return out

def cover_parts(explode=0,shutter_out=0,hardware=True,main=True,shutters=True,conceal=True):
    variant='powered' if POWERED else 'passive'
    count=5 if POWERED else 3
    end=826 if POWERED else 496
    pitch=(end+46)/count
    out=[]
    for i in range(count):
        x=-46+i*pitch
        name=('left' if i==0 else 'right' if i==count-1 else
              'transition' if POWERED and i==3 else
              'pole-middle' if POWERED and i==1 else 'middle')
        # Inverse of canonical print transform; reused meshes, no proxy shells.
        b=np.array([[0,0,1,x-(8 if i==0 else 0)],[1,0,0,-100],[0,1,0,-32+explode+i*(12 if explode else 0)],[0,0,0,1]])
        if main:out.append(A(f'cover-{variant}-{name}',b))
        if shutters and i<count-1:
            b=np.array([[1,0,0,x],[0,0,-1,84+shutter_out],[0,1,0,14],[0,0,0,1]])
            out.append(A(f'cover-{variant}-shutter',b))
        for cx in [x+16,x+pitch-16]:
            for sy in [-1,1]:
                out.append(A('cover-clip',T(cx)@np.diag([1,sy,1,1])@T(-10,68)))
                if hardware:
                    out.extend([H('bolt-M4x25',T(cx,sy*82,6.8)@R('x',180)),H('washer-M4',T(cx,sy*82,6)),H('washer-M4',T(cx,sy*82,-8.8)),H('nyloc-M4',T(cx,sy*82,-13.8))])
                    # Keep every metal stack in the scene; actual fascia meshes occlude them.
                    out.append(H('nut-M4',T(cx,sy*72.2,24)@R('x',90 if sy==1 else -90)))
                    if main and not explode and not shutter_out:
                        rot=R('x',90 if sy==1 else -90)
                        out.extend([H('bolt-M4x16',T(cx,sy*80.8,24)@rot),H('washer-M4',T(cx,sy*80.8,24)@rot)])
        if conceal and main:
            for sy in [-1,1]:
                b=np.array([[1,0,0,x],[0,0,-1,98],[0,1,0,-32],[0,0,0,1]])
                name=f'cover-{variant}-'+('pole-fascia' if sy==-1 and i==(1 if POWERED else 0) else 'fascia')
                out.append(A(name,T(0,sy*(55 if explode else 0),2 if explode else 0)@np.diag([1,sy,1,1])@b))
    if conceal and main:
        for left,number in [(True,2 if POWERED else 1),(False,3 if POWERED else 2)]:
            start=-50 if left else W/2+51
            stop=W/2-51 if left else end+4
            length=(stop-start)/number
            for i in range(number):
                out.append(A(f'cover-{variant}-rear-{"left" if left else "right"}',T(start+i*length,-93.2,-27.6-(50 if explode else 0))))
        out.append(A('cover-rear-blank',T(W/2-50.5,-93.2,-27.6-(50 if explode else 0))))
    out.append(A('cover-cable-anchor',T(W/2+42,-72)))
    if hardware:
        for cx in [W/2+50,W/2+70]:
            out.extend([H('bolt-M4x25',T(cx,-60,6.8)@R('x',180)),H('washer-M4',T(cx,-60,6)),H('washer-M4',T(cx,-60,-8.8)),H('nyloc-M4',T(cx,-60,-13.8))])
    return out

def covered(explode=0,shutter_out=0,main=True,shutters=True,conceal=True):
    variant='powered' if POWERED else 'passive'
    out=[p for p in full(guard=True) if 'base-plate' not in p['file']]
    out.append(H(f'base-plate-{variant}-covered',c=STEEL))
    out+=cover_parts(explode,shutter_out,main=main,shutters=shutters,conceal=conceal)
    out.append(H('line-'+variant+'-reference',T(6+W/2,50,130.9 if POWERED else 130.3)@R('x',-90),CORE))
    end=826 if POWERED else 496
    for i in [0,1]:out.append(H('loom-'+variant+'-bottom-'+str(i),c=CORE))
    return out


def pole_mounted(caps=True):
    out=[p for p in covered() if 'cover-rear-blank' not in p['file']]
    out.append(H('pole-timber-120',T(W/2),(.48,.32,.16)))
    out[-1]['fit']=False  # Continuing contextual pole must not shrink the winch view.
    for y in [-60,60]:
        out += [A('pole-front-saddle',T(W/2,y),), A('pole-rear-saddle',T(W/2,y))]
        # Saddles are metal fabrication references; never printable substitutes.
        out[-1]['color']=STEEL;out[-2]['color']=STEEL
        if caps:
            out.append(A('pole-nut-cover',T(W/2-48,y-18,-195)))
            out.append(A('pole-nut-cover-bottom',T(W/2-44,y-20,-193)))
        for x in [W/2-25,W/2+25]:
            out += [H('bolt-M8x180',T(x,y,1.6)@R('x',180)),H('washer-M8',T(x,y,0)),
                    H('washer-M8',T(x,y,-162.6)),H('nyloc-M8',T(x,y,-162.6)@R('x',180))]
    out.append(A('pole-cable-guide',T(W/2-25,-238,-34)))
    for y in [-233,-227]:out.append(H('pole-guide-tie-120',T(W/2,y),CORE))
    return out


def polydata(file):
    if file not in cache:
        assert (ROOT/file).is_file(), 'Missing figure mesh: '+file
        read=vtk.vtkSTLReader();read.SetFileName(str(ROOT/file));read.Update()
        assert read.GetOutput().GetNumberOfCells()>0, 'Empty figure mesh: '+file
        cache[file]=read.GetOutput()
    return cache[file]

def render(name,parts,direction=(.55,-1,.65),up=(0,0,1),size=(1500,950),anchors=None,fit_bounds=None):
    ren=vtk.vtkRenderer();ren.SetBackground(1,1,1)
    win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetSize(*size);win.SetMultiSamples(8);win.AddRenderer(ren)
    bounds=[]
    for part in parts:
        pd=polydata(part['file']);matrix=vtk.vtkMatrix4x4()
        mm=np.array(part['matrix'])
        for i in range(4):
            for j in range(4):matrix.SetElement(i,j,mm[i,j])
        mapper=vtk.vtkPolyDataMapper();mapper.SetInputData(pd);mapper.ScalarVisibilityOff()
        mapper.SetResolveCoincidentTopologyToPolygonOffset()
        actor=vtk.vtkActor();actor.SetMapper(mapper);actor.SetUserMatrix(matrix)
        # Opaque white faces occlude hidden edges. Product/PCB colors stay in
        # assembly manifests and the GLB, but never obscure booklet detail.
        prop=actor.GetProperty();prop.SetColor(1,1,1);prop.LightingOff();ren.AddActor(actor)
        # Include camera-dependent curved outlines, not every STL triangle.
        # Prop3D applies the same assembly rotation/reflection to the view.
        edges=vtk.vtkPolyDataSilhouette();edges.SetInputData(pd)
        edges.SetCamera(ren.GetActiveCamera());edges.SetDirectionToCameraVector();edges.SetProp3D(actor)
        edges.SetEnableFeatureAngle(1);edges.SetFeatureAngle(34);edges.BorderEdgesOn()
        em=vtk.vtkPolyDataMapper();em.SetInputConnection(edges.GetOutputPort());em.ScalarVisibilityOff()
        ea=vtk.vtkActor();ea.SetMapper(em);ea.SetUserMatrix(matrix)
        ea.GetProperty().SetColor(.12,.12,.12);ea.GetProperty().SetLineWidth(1.5);ea.GetProperty().LightingOff();ren.AddActor(ea)
        b=pd.GetBounds()
        pts=np.array([[x,y,z,1] for x in b[:2] for y in b[2:4] for z in b[4:6]])
        if part.get('fit',True):bounds.extend((mm@pts.T).T[:,:3])
    bounds=np.array(bounds if fit_bounds is None else fit_bounds);center=(bounds.max(0)+bounds.min(0))/2
    d=np.array(direction,dtype=float);d/=np.linalg.norm(d);u=np.array(up,dtype=float)
    right=np.cross(-d,u);right/=np.linalg.norm(right);vertical=np.cross(right,-d)
    xs=(bounds-center)@right;ys=(bounds-center)@vertical
    scale=max(np.ptp(ys)/2,np.ptp(xs)/2/(size[0]/size[1]))*1.13
    camera=ren.GetActiveCamera();camera.ParallelProjectionOn();camera.SetFocalPoint(*center);camera.SetPosition(*(center+d*2000));camera.SetViewUp(*up);camera.SetParallelScale(scale)
    ren.ResetCameraClippingRange();win.Render()
    projection={}
    for label,xyz in (anchors or {}).items():
        ren.SetWorldPoint(*xyz,1);ren.WorldToDisplay();p=ren.GetDisplayPoint();projection[label]=[p[0]/size[0],p[1]/size[1]]
    capture=vtk.vtkWindowToImageFilter();capture.SetInput(win);capture.ReadFrontBufferOff();capture.Update()
    writer=vtk.vtkPNGWriter();writer.SetFileName(str(FIGS/(name+'.png')));writer.SetInputConnection(capture.GetOutputPort());writer.Write()
    manifest[name]={'parts':parts,'anchors':projection,'size':list(size),'render_style':'assembly-line-art-v1'}
    win.Finalize()
    print('Rendered '+name,flush=True)

def main():
    global W,POWERED
    render('finished',full(guard=True,feet=True),size=(1800,1000))
    for name in ['drum-passive-1','drum-passive-2','drum-flange','drum-flange-right','drum-clamp-half',
      'drum-tail-clamp','drum-alignment-pin','bearing-lower','bearing-cap','motor-stand','coupling-guard',
      'desk-foot-short','desk-foot-long']:
        render('part-'+name,[A(name)],direction=(1,-1,.9),size=(650,480))
    for name in ['motor-23HS40-reference','bearing-608','inner-ring-spacer','shaft-collar-8','shaft-8x340',
      'tie-rod-M5x280','base-plate-passive','bolt-M4x25','nyloc-M4','washer-M4','nut-M5']:
        mat=R('y',90) if name in ['motor-23HS40-reference','shaft-8x340','tie-rod-M5x280'] else np.eye(4)
        render('ref-'+name,[H(name,mat)],direction=(.5,-1,.7),size=(700,480))
    render('coupling-parts',coupling(explode=10),direction=(.25,-1,.6),size=(1000,450))
    render('drum-exploded',transform(drum_parts(explode=32,clamp=False,tail=False,hardware=False),R('y',90)),direction=(-.45,-1,.7),size=(1800,800))
    render('drum-endface',[A('drum-passive-1')],direction=(0,0,1),up=(0,1,0),size=(650,650),anchors={'pin':[26,0,123.45]})
    prep=[A('drum-flange-right',R('x',180))]
    for x in [-26,26]:
        for y in [-9,9]:prep.extend([H('bolt-M4x25',T(x,y,-6.8)),H('washer-M4',T(x,y,-6.8))])
    render('flange-preload',prep,direction=(.6,-1,.65),size=(1000,700))
    render('tie-rods',transform(drum_parts(clamp=False,tail=False),R('y',90)),direction=(-.4,-1,.75),size=(1500,700))
    render('rod-hardware',[H('tie-rod-M5x280',R('y',90)),H('washer-M5',T(-12)@R('y',90)),H('nyloc-M5',T(-24)@R('y',90)),H('washer-M5',T(291)@R('y',90)),H('nyloc-M5',T(303)@R('y',90))],direction=(.15,-1,.55),size=(1600,330))
    rc=[A('drum-flange-right',R('x',180)),{**H('shaft-8x340',T(z=-310)),'fit':False}]
    halves=[A('drum-clamp-half',T(y=15,z=18)),A('drum-clamp-half',T(y=-15,z=18)@R('z',180))]
    render('clamp-exploded',rc+halves,direction=(1,-1,.85),size=(1300,900))
    clamp=[A('drum-flange-right',R('x',180)),A('drum-clamp-half'),A('drum-clamp-half',R('z',180)),{**H('shaft-8x340',T(z=-310)),'fit':False}]
    clamp+=transform(clamp_hardware(),T(z=-W-12))
    render('clamp-complete',clamp,direction=(.9,-1,1.4),size=(1300,900))
    render('base-supports',supports(caps=False,bolts=True),direction=(.55,-1,.9),size=(1700,850))
    p=[A('bearing-lower'),A('bearing-cap',T(z=113)),H('bearing-608',T(-3.5,0,80)@R('y',90))]
    for y in [-18,18]:p.extend([H('nut-M5',T(-16,y,67.25)),H('bolt-M5x35',T(0,y,155)@R('x',180)),H('washer-M5',T(0,y,134))])
    render('bearing-exploded',p,direction=(-1,-1,.7),size=(1100,900))
    moving=transform(drum_parts(shaft=True)+clamp_hardware(),DR)+rings()
    render('shaft-drop',supports(caps=False,motor=False)+transform(moving,T(z=65)),direction=(.25,-1,.55),size=(1750,900))
    render('shaft-seated',supports(cap_lift=42,motor=False)+moving,direction=(.35,-1,.8),size=(1700,800))
    render('left-stack',[H('shaft-collar-8',T(-44,0,80)@R('y',90)),H('inner-ring-spacer',T(-23,0,80)@R('y',90)),H('bearing-608',T(-9,0,80)@R('y',90)),A('drum-flange',DR),{**H('shaft-8x340',T(-27.1,0,80)@R('y',90)),'fit':False}],direction=(.1,-1,.65),size=(1500,600))
    motor=[A('motor-stand',T(W+93)),H('motor-23HS40-reference',T(W+93,0,80)@R('y',90),DARK)]+motor_hardware()
    render('motor-mount',motor,direction=(-.65,-1,.6),size=(1200,800))
    # Local cutaway-style gap view: the true 340 mm shaft and motor are cropped by camera in the PDF.
    render('motor-coupling',full(guard=False),direction=(.1,-1,.45),size=(1850,650))
    close=[A('bearing-lower',T(W+37.5)@R('z',180)),A('bearing-cap',T(W+37.5,0,80.2)),
      A('motor-stand',T(W+93)),H('motor-23HS40-reference',T(W+93,0,80)@R('y',90),DARK)]
    close+=motor_hardware()+coupling()+[H('inner-ring-spacer',T(W+41,0,80)@R('y',90)),H('shaft-collar-8',T(W+43,0,80)@R('y',90))]
    render('coupling-close',close,direction=(-.3,-1,.65),size=(1400,850))
    gap_parts=[H('shaft-8x340',T(-27.1,0,80)@R('y',90)),H('motor-23HS40-reference',T(W+93,0,80)@R('y',90))]
    render('shaft-tip-gap',gap_parts,direction=(0,-1,0),size=(1200,450),fit_bounds=[[300,-8,69],[331,8,91]],anchors={'left':[312.9,0,80],'right':[317.9,0,80]})
    tail=[A('drum-flange-right',R('x',180)),A('drum-clamp-half'),A('drum-clamp-half',R('z',180)),A('drum-tail-clamp',T(-14,49,18))]
    for x in [-9,9]:tail.append(H('bolt-M4x25',T(x,55,41)@R('x',180)))
    render('tail-location',tail,direction=(.4,-1,1.7),size=(1100,1000))
    render('tail-underside',[A('drum-tail-clamp',R('x',180))],direction=(.65,-1,.9),size=(900,550))
    route=[A('drum-flange-right',R('x',180)),A('drum-clamp-half'),A('drum-clamp-half',R('z',180)),A('drum-tail-clamp',T(86,55,6)@R('x',180))]
    render('tail-routing',route,direction=(0,0,1),up=(0,1,0),size=(1500,950),anchors={str(i):p for i,p in enumerate([(0,72,1),(0,63,1),(22,63,1),(22,58,1),(-20,58,1),(-24,55,1),(-20,52,1),(22,52,1),(-14,49,1),(14,61,1)])})
    guard=[A('coupling-guard',T(W+85,0,135)@R('y',-90))]+close
    render('guard-fit',guard,direction=(-.7,-1,.5),size=(1500,1000))
    render('guard-underside',[A('coupling-guard',R('x',180))],direction=(-.8,-1,.65),size=(900,650))
    render('guard-installed',[A('coupling-guard',T(W+85,0,80)@R('y',-90))]+close+cover_hardware(),direction=(-.65,-1,.4),size=(1350,800))
    render('feet-install',[H('base-plate-passive')]+desk_feet(drop=22),direction=(.4,-1,.55),size=(1800,800))
    render('feet-final',full(guard=True,feet=True),direction=(-.25,-1,.7),size=(1800,1000))
    render('cover-passive-installed',covered(),direction=(.35,1,.7),up=(0,1,0),size=(1800,1000))
    render('cover-passive-exploded',covered(explode=190,shutter_out=90),direction=(.35,1,.7),up=(0,1,0),size=(1800,1200),anchors={'hood_base':[50,-60,164],'hood_out':[50,-60,354],'shutter_base':[50,78,60],'shutter_out':[50,168,60]})
    render('cover-shutter-removal',covered(shutter_out=60,conceal=False),direction=(.35,1,.7),up=(0,1,0),size=(1800,1000))
    render('cover-core-service',covered(main=False,shutters=False),direction=(.35,1,.7),up=(0,1,0),size=(1800,1000))
    render('cover-clip-detail',[A('cover-clip'),H('nut-M4',T(-12,4.2,24)@R('x',90)),H('bolt-M4x16',T(10,32,24)@R('x',90)),H('washer-M4',T(10,24,24)@R('x',90))],direction=(-1,-1,.7),size=(1000,700))
    render('cover-base-drilling',[H('base-plate-passive-covered')],direction=(0,0,1),up=(0,1,0),size=(1800,750))
    render('cover-concealment-rear',covered(),direction=(.25,-.6,-1),up=(0,1,0),size=(1500,900))
    render('cover-rear-ports',covered(),direction=(1,-.3,.35),up=(0,1,0),size=(1300,900))
    render('round-pole-installed',pole_mounted(),direction=(.45,-.25,1),up=(0,1,0),size=(1800,1300))
    render('round-pole-rear-open',pole_mounted(caps=False),direction=(.6,.25,-1),up=(0,1,0),size=(1800,1300))
    POWERED=True;W=570.3
    render('cover-powered-installed',covered(),direction=(.25,1,.65),up=(0,1,0),size=(2000,900))
    render('cover-powered-exploded',covered(explode=190,shutter_out=90),direction=(.3,1,.7),up=(0,1,0),size=(2000,1100))
    POWERED=False;W=246.9
    (ROOT/'figure-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (ROOT/'tail-routing-anchors.json').write_text(json.dumps(manifest['tail-routing']['anchors'])+'\n')
    (ROOT/'shaft-gap-anchors.json').write_text(json.dumps(manifest['shaft-tip-gap']['anchors'])+'\n')

if __name__=='__main__':main()
