from pathlib import Path
import json,math
import numpy as np
import vtk
ROOT=Path(__file__).resolve().parents[1]
FIGS=ROOT/"figures"
FIGS.mkdir(exist_ok=True)
cache={}
manifest={}
def T(x=0,y=0,z=0):
    m=np.eye(4);m[:3,3]=[x,y,z];return m

def R(axis,angle):
    a=np.deg2rad(angle);c,s=np.cos(a),np.sin(a);m=np.eye(4)
    if axis=='x':m[:3,:3]=[[1,0,0],[0,c,-s],[0,s,c]]
    elif axis=='y':m[:3,:3]=[[c,0,s],[0,1,0],[-s,0,c]]
    else:m[:3,:3]=[[c,-s,0],[s,c,0],[0,0,1]]
    return m

def polydata(file):
    if file not in cache:
        assert (ROOT/file).is_file(), 'Missing figure mesh: '+file
        read=vtk.vtkSTLReader();read.SetFileName(str(ROOT/file));read.Update()
        assert read.GetOutput().GetNumberOfCells()>0, 'Empty figure mesh: '+file
        cache[file]=read.GetOutput()
    return cache[file]

def render(name,parts,direction=(.55,-1,.65),up=(0,0,1),size=(1500,950),anchors=None,fit_bounds=None):
    ren=vtk.vtkRenderer();ren.SetBackground(1,1,1)
    win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetSize(*size);win.SetMultiSamples(8);win.AddRenderer(ren)
    bounds=[]
    for part in parts:
        pd=polydata(part['file']);matrix=vtk.vtkMatrix4x4()
        mm=np.array(part['matrix'])
        for i in range(4):
            for j in range(4):matrix.SetElement(i,j,mm[i,j])
        mapper=vtk.vtkPolyDataMapper();mapper.SetInputData(pd);mapper.ScalarVisibilityOff()
        mapper.SetResolveCoincidentTopologyToPolygonOffset()
        actor=vtk.vtkActor();actor.SetMapper(mapper);actor.SetUserMatrix(matrix)
        # Opaque white faces occlude hidden edges. Product/PCB colors stay in
        # assembly manifests and the GLB, but never obscure booklet detail.
        prop=actor.GetProperty();prop.SetColor(1,1,1);prop.LightingOff();ren.AddActor(actor)
        # Include camera-dependent curved outlines, not every STL triangle.
        # Prop3D applies the same assembly rotation/reflection to the view.
        edges=vtk.vtkPolyDataSilhouette();edges.SetInputData(pd)
        edges.SetCamera(ren.GetActiveCamera());edges.SetDirectionToCameraVector();edges.SetProp3D(actor)
        edges.SetEnableFeatureAngle(1);edges.SetFeatureAngle(34);edges.BorderEdgesOn()
        em=vtk.vtkPolyDataMapper();em.SetInputConnection(edges.GetOutputPort());em.ScalarVisibilityOff()
        ea=vtk.vtkActor();ea.SetMapper(em);ea.SetUserMatrix(matrix)
        ea.GetProperty().SetColor(.12,.12,.12);ea.GetProperty().SetLineWidth(1.5);ea.GetProperty().LightingOff();ren.AddActor(ea)
        b=pd.GetBounds()
        pts=np.array([[x,y,z,1] for x in b[:2] for y in b[2:4] for z in b[4:6]])
        if part.get('fit',True):bounds.extend((mm@pts.T).T[:,:3])
    bounds=np.array(bounds if fit_bounds is None else fit_bounds);center=(bounds.max(0)+bounds.min(0))/2
    d=np.array(direction,dtype=float);d/=np.linalg.norm(d);u=np.array(up,dtype=float)
    right=np.cross(-d,u);right/=np.linalg.norm(right);vertical=np.cross(right,-d)
    xs=(bounds-center)@right;ys=(bounds-center)@vertical
    scale=max(np.ptp(ys)/2,np.ptp(xs)/2/(size[0]/size[1]))*1.13
    camera=ren.GetActiveCamera();camera.ParallelProjectionOn();camera.SetFocalPoint(*center);camera.SetPosition(*(center+d*2000));camera.SetViewUp(*up);camera.SetParallelScale(scale)
    ren.ResetCameraClippingRange();win.Render()
    projection={}
    for label,xyz in (anchors or {}).items():
        ren.SetWorldPoint(*xyz,1);ren.WorldToDisplay();p=ren.GetDisplayPoint();projection[label]=[p[0]/size[0],p[1]/size[1]]
    capture=vtk.vtkWindowToImageFilter();capture.SetInput(win);capture.ReadFrontBufferOff();capture.Update()
    writer=vtk.vtkPNGWriter();writer.SetFileName(str(FIGS/(name+'.png')));writer.SetInputConnection(capture.GetOutputPort());writer.Write()
    manifest[name]={'parts':parts,'anchors':projection,'size':list(size),'render_style':'assembly-line-art-v1'}
    win.Finalize()
    print('Rendered '+name,flush=True)
