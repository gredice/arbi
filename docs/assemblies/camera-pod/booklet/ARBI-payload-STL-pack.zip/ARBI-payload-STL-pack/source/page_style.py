"""Build the corrected A4 assembly booklet from STL-rendered illustrations."""
from pathlib import Path
import json,math
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.units import mm
from reportlab.lib.colors import HexColor,white
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.lib.utils import ImageReader

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'ARBI-payload-assembly-STL.pdf'
pdfmetrics.registerFont(TTFont('ARBI',str(ROOT/'source/fonts/DejaVuSans.ttf')))
pdfmetrics.registerFont(TTFont('ARBI-Bold',str(ROOT/'source/fonts/DejaVuSans-Bold.ttf')))
pdfmetrics.registerFontFamily('ARBI',normal='ARBI',bold='ARBI-Bold',italic='ARBI',boldItalic='ARBI-Bold')
C=canvas.Canvas(str(OUT),pagesize=(210*mm,297*mm))
C.setTitle('ARBI payload - printed mount assembly booklet')
C.setAuthor('ARBI / Gredice')
BLUE=HexColor('#158dcc');INK=HexColor('#15232d');GRAY=HexColor('#53616a');LINE=HexColor('#d3dfe6')
STYLE=ParagraphStyle('body',fontName='ARBI',fontSize=10,leading=13,textColor=INK,spaceAfter=0)
SMALL=ParagraphStyle('small',parent=STYLE,fontSize=8.5,leading=11)
PAGE=0

def text(x,y,s,size=10,bold=False,color=INK):
    C.setFillColor(color);C.setFont('ARBI-Bold' if bold else 'ARBI',size);C.drawString(x*mm,(297-y)*mm,s)
def para(x,y,w,s,small=False,max_h=None):
    p=Paragraph(s,SMALL if small else STYLE);_,h=p.wrap(w*mm,1000)
    if max_h is not None:assert h<=max_h*mm,(s,h/mm,max_h)
    p.drawOn(C,x*mm,(297-y)*mm-h);return h/mm
def line(x,y,x2,y2,color=LINE,width=.5):
    C.setStrokeColor(color);C.setLineWidth(width);C.line(x*mm,(297-y)*mm,x2*mm,(297-y2)*mm)
def box(x,y,w,h,fill='#f1f8fc'):
    C.setFillColor(HexColor(fill));C.setStrokeColor(LINE);C.setLineWidth(.5);C.roundRect(x*mm,(297-y-h)*mm,w*mm,h*mm,2*mm,fill=1,stroke=1)
def fig(name,x,y,w,h):
    from PIL import Image
    path=ROOT/'figures'/(name+'.png');im=Image.open(path);iw,ih=im.size
    scale=min(w/iw,h/ih);ww,hh=iw*scale,ih*scale;xx=x+(w-ww)/2;yy=y+(h-hh)/2
    C.drawImage(str(path),xx*mm,(297-yy-hh)*mm,ww*mm,hh*mm)
    return xx,yy,ww,hh
def arrow(x,y,x2,y2):
    line(x,y,x2,y2,BLUE,1.4);a=math.atan2(y2-y,x2-x)
    for off in [-.55,.55]:line(x2,y2,x2-3*math.cos(a+off),y2-3*math.sin(a+off),BLUE,1.4)
def step(n,x,y,title,body,w=178):
    C.setFillColor(BLUE);C.circle((x+3.5)*mm,(297-y-3.5)*mm,3.5*mm,fill=1,stroke=0)
    text(x+2.35,y+4.65,str(n),10,True,white)
    text(x+10,y+5,title,12,True)
    if body:para(x+10,y+10,w-10,body)
def note(y,s):
    box(16,y,178,21);para(20,y+4,170,s,small=True,max_h=15)
def begin(title,subtitle=''):
    global PAGE
    if PAGE:C.showPage()
    PAGE+=1
    text(16,17,'ARBI',22,True,BLUE);text(43,17,'PAYLOAD',15,True)
    text(141,15,'MOUNT SET / BENCH EDITION',7,True,GRAY)
    line(16,23,194,23,BLUE,.8)
    text(16,35,title,20,True)
    if subtitle:para(16,39,178,subtitle,small=True,max_h=12)
    line(16,284,194,284,BLUE,.7)
    text(16,290,'ARBI | Payload bench assembly | Revision 2 | 28 Sep 2026',7,color=GRAY)
    text(176,290,f'{PAGE:02d} / 14',8,True,GRAY)

